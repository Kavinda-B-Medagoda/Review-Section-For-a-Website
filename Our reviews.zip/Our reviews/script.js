const review = [

    {
        id: 1,
        Name: "Thisitha Medagoda",
        Job: "Business Analysis",
        info: "Lorem ipsum dolor sits sads amet consectetur adipisicing elit.Delectus facilis accusantium veniam, sed aliquid ut eveniet cumque reprehenderit quos aperiam corrupti culpa aspernatur, doloremque officiis!",
        img: "./images/p1.jpg"  
    },

    {
        id: 2,
        Name: "Sanduni Rathnayake",
        Job: "Content Creator",
        info: "Lorem ipsum dolor sit amet consectetur adipisicing elit.Delectus facilis accusantium veniam, sed aliquid ut eveniet cumque reprehenderit quos aperiam corrupti culpa aspernatur, doloremque officiis!",
        img: "./images/p5.jpg"  
    },

    {
        id: 3,
        Name: "Kavinda Medagoda",
        Job: "Entrepreneur",
        info: "ilis accusantium veniam sed aliquid ut eveniet cumque reprehenderit quos aperiam corrupti culpa aspernatur, doloremque officiis!",
        img: "./images/p3.jpg"  
    },

    {
        id: 4,
        Name: "Thanuri Chandrasiri",
        Job: "Graphic Designer",
        info: " sdsdd  sss Lorem ipsum dolor sit amet consectetur adipisicing elit. accusantium veniam, sed aliquid ut eveniet cumque reprehenderit quos aperiam corrupti culpa aspernatur, doloremque officiis!",
        img: "./images/p2.jpg"  
    },

    {
        id: 5,
        Name: "Ashan Sandeepa",
        Job: "Army Solider",
        info: "Lorem ipsum sdsdsda sdasds sdasda asdasd  dolor sit amet consectetur adipisicing elit.Delectus facilis accusantium veniam, sed aliquid ut eveniet cumque reprehenderit quos aperiam corrupti culpa aspernatur, doloremque officiis!",
        img: "./images/p4.jpg"  
    }

    
]


let img = document.getElementById("img");
let author = document.getElementById("author");
let job = document.getElementById("job");
let info = document.getElementById("info");

let currentContent = 0;

let prev_btn = document.querySelector(".prev-btn");
let next_btn = document.querySelector(".next-btn");
let random = document.querySelector(".random-btn");



window.addEventListener("DOMContentLoaded", function(){
    func1(currentContent);
})


function func1(person){
    const item = review[person];
    img.src = item.img;
    author.textContent = item.Name;
    job.textContent = item.Job;
    info.textContent = item.info;
}



next_btn.addEventListener("click", function(){
    
    currentContent += 1;
    if (currentContent==(review.length-1)) {
        currentContent = 0;
    }
    func1(currentContent);
})


prev_btn.addEventListener("click", function(){
    
    currentContent -= 1;
    if (currentContent<0) {
        currentContent = review.length-1;
    }
    func1(currentContent);
})

random.addEventListener("click", function(){
    
    currentContent = Math.floor(Math.random() * review.length);
    func1(currentContent);
})




